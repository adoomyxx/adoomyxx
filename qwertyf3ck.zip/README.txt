qwertyf3ck is a malware that destroys your PC very hard, harder than Dioxide.exe

Disclaimer: The malware is dangerous and dont change the name and scam people into destroying their PC, Doing that could put you into
Prison or Jail, so just run it on a vm (virtual machine)