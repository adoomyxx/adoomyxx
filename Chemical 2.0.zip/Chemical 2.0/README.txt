File Type: Batch File Virus
Type of Virus: Trojan:killsys!ntfs

README: Do not run this on Real Machines, if you wanna test this, Get a VM