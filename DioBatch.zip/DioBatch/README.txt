This is a batch malware, This is destructive and deletes the boot manager Get a vm and run this
make sure That the vm is a windows machine